package CRUD;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author joel jorle
 */
import java.io.*;
import java.net.URISyntaxException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.EnumSet;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * The type File crud.
 */

public class FileCrud {


    /**
     * Create properties file file.
     *
     * @param relativeFilePath the relative file path
     * @return the file
     * @throws URISyntaxException the uri syntax exception
     */
    public final  static File createPropertiesFile(String relativeFilePath) throws
            URISyntaxException {
        return new File(new
                File(FileCrud.class.getProtectionDomain().getCodeSource().getLocation().toURI()),
                relativeFilePath);
    }

    /**
     * Save file file.
     *
     * @param params the params
     * @return the file
     */
    public final static File saveFile(Object... params)
    { File rep=null;
 try {
     Path path=(params.length<2)?Paths.get((String)params[0]):((File)params[1]).toPath();
      rep=Files.createFile(path).toFile();
    }catch (Exception e)
   {
   e.printStackTrace();
 }

    return  rep;
    }


    /**
     * Delete file boolean.
     *
     * @param params the params
     * @return the boolean
     */
    public final static boolean deleteFile(Object... params)
    { Boolean rep=false;Path path=null;
        try {

            path=(params.length<2)?Paths.get((String)params[0]):((File)params[1]).toPath();
            rep=Files.deleteIfExists(path);

        }catch (Exception e)
        {
            e.printStackTrace();
        }

        return  rep;
    }


    /**
     * Create directorie file.
     *
     * @param params the params
     * @return the file
     */
    public final static File createDirectorie(Object... params)
    { File rep=null;

        try {
            Path path = Paths.get((String) params[0]);
            if(!Files.exists(path))Files.createDirectory(path);
            rep=path.toFile();
        }catch (Exception e)
        {
            e.printStackTrace();
        }

    return  rep;}

    /**
     * Decompresser.
     *
     * @param nomArchive the nom archive
     * @param chemin     the chemin
     */
    public static void decompresser(String nomArchive, String chemin) {
            try {
                ZipFile zipFile = new ZipFile(nomArchive);
                Enumeration entries = zipFile.entries();
                ZipEntry entry = null;
                File fichier = null;
                File sousRep = null;
                while (entries.hasMoreElements()) {
                    entry = (ZipEntry) entries.nextElement();
                    if (!entry.isDirectory()) {
                        fichier = new File(chemin + File.separatorChar + entry.getName());
                        sousRep = fichier.getParentFile();
                        if (sousRep != null) {
                            if (!sousRep.exists()) {
                                sousRep.mkdirs();
                            }
                        }
                        int i = 0;
                        byte[] bytes = new byte[1024];
                        BufferedOutputStream out = new BufferedOutputStream(
                                new FileOutputStream(fichier));
                        BufferedInputStream in = new BufferedInputStream(zipFile
                                .getInputStream(entry));
                        while ((i = in.read(bytes)) != -1)
                            out.write(
                                    bytes,
                                    0,
                                    i);
                        in.close();
                        out.flush();
                        out.close();
                    }
                }
                zipFile.close();
            } catch (FileNotFoundException fnfe) {
                fnfe.printStackTrace();
            } catch (IOException ioe) {
                ioe.printStackTrace();
            }

    }


    /**
     * Delete directorie boolean.
     *
     * @param params the params
     * @return the boolean
     */
    public final static boolean deleteDirectorie(Object... params)
    { Boolean rep=false;Path path=null;
        try {
        path=(params.length<2)?Paths.get((String)params[0]):((File)params[1]).toPath();
        DeleteDirectory walk = new DeleteDirectory();
        EnumSet<FileVisitOption> opts = EnumSet.of(FileVisitOption.FOLLOW_LINKS);
        Files.walkFileTree(path, opts, Integer.MAX_VALUE, walk);
    }catch (Exception e)
    {
        e.printStackTrace();
    }

        return  rep;
    }


    /**
     * Search file file.
     *
     * @param params the params
     * @return the file
     */
    public final static File searchFile(Object... params)
    { File rep=null;

        try {

          Path  path=(params.length<2)?Paths.get((String)params[0]):((File)params[1]).toPath();
          Search walk = new Search(path);
          rep=walk.foundFile;

        }catch (Exception e)
        {
            e.printStackTrace();
        }


        return  rep;}


    /**
     * The type Delete directory.
     */
    static class DeleteDirectory implements FileVisitor {
        /**
         * Delete file by file boolean.
         *
         * @param file the file
         * @return the boolean
         * @throws IOException the io exception
         */
        boolean deleteFileByFile(Path file) throws IOException {
            return Files.deleteIfExists(file);
        }

        @Override
        public FileVisitResult postVisitDirectory(Object dir, IOException exc)
                throws IOException {
            if (exc == null) {
                System.out.println("Visited: " + (Path) dir);
                boolean success = deleteFileByFile((Path) dir);
                if (success) {
                    System.out.println("Deleted: " + (Path) dir);
                } else {
                    System.out.println("Not deleted: " + (Path) dir);
                }
            } else {
                throw exc;
            }
            return FileVisitResult.CONTINUE;
        }

        @Override
        public FileVisitResult preVisitDirectory(Object dir, BasicFileAttributes attrs)
                throws IOException {
            return FileVisitResult.CONTINUE;
        }

        @Override
        public FileVisitResult visitFile(Object file, BasicFileAttributes attrs)
                throws IOException {
            deleteFileByFile((Path) file);
            return FileVisitResult.CONTINUE;
        }

        @Override
        public FileVisitResult visitFileFailed(Object file, IOException exc)
                throws IOException {
//report an error if necessary
            return FileVisitResult.CONTINUE;
        }
    }

    /**
     * The type Search.
     */
    static class Search implements FileVisitor {
        private final Path searchedFile;
        /**
         * The Found.
         */
        public boolean found;
        /**
         * The Found file.
         */
        public File foundFile;

        /**
         * Instantiates a new Search.
         *
         * @param searchedFile the searched file
         */
        public Search(Path searchedFile) {
            this.searchedFile = searchedFile;
            this.found = false;
        }

        /**
         * Search.
         *
         * @param file the file
         * @throws IOException the io exception
         */
        void search(Path file) throws IOException {
            Path name = file.getFileName();
            if (name != null && name.equals(searchedFile)) {
                foundFile=file.toFile();
                found = true;
            }
        }

        @Override
        public FileVisitResult postVisitDirectory(Object dir, IOException exc)
                throws IOException {
            return FileVisitResult.CONTINUE;
        }

        @Override
        public FileVisitResult preVisitDirectory(Object dir, BasicFileAttributes attrs)
                throws IOException {
            return FileVisitResult.CONTINUE;
        }
        @Override
        public FileVisitResult visitFile(Object file, BasicFileAttributes attrs)
                throws IOException {
            search((Path) file);
            if (!found) {
                return FileVisitResult.CONTINUE;
            } else {
                return FileVisitResult.TERMINATE;
            }
        }
        @Override
        public FileVisitResult visitFileFailed(Object file, IOException exc)
                throws IOException {
//report an error if necessary
            return FileVisitResult.CONTINUE;
        }
    }


}
